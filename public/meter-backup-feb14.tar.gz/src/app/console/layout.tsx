export default function ConsoleLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
